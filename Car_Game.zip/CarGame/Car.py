from random import randint
import pygame
from SpawnCar import Spawn
pygame.init()
pygame.mixer.music.load("Music.mp3")
pygame.mixer.music.play(-1)
pygame.display.set_caption("Обходи препятствия!")
pygame.display.set_icon(pygame.image.load("Car_2.png"))
pygame.time.set_timer(pygame.USEREVENT, 2000)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
W, H = 1000, 600
animCount = 0
sc = pygame.display.set_mode((W, H))
bg = [pygame.image.load('frame_1.png'), pygame.image.load('frame_2.png'), pygame.image.load('frame_3.png'),
      pygame.image.load('frame_4.png'), pygame.image.load('frame_5.png'), pygame.image.load('frame_6.png')]

clock = pygame.time.Clock()
FPS = 60
score = pygame.image.load('Score.png').convert_alpha()
f = pygame.font.SysFont('IMPACT', 30)
f2 = pygame.font.SysFont('IMPACT', 30)
f3 = pygame.font.SysFont('IMPACT', 200)
f4 = pygame.font.SysFont('IMPACT', 30)
car_a = pygame.image.load('машина1.png').convert_alpha()
c_rect = car_a.get_rect(centerx=W // 2, bottom=H - 5)
cars_im = ['Car_2.png', 'Car_3.png', 'Car_4.png']
cars_surf = [pygame.image.load(path).convert_alpha() for path in cars_im]
lifes = 3
animcount = 0


# Анимация дороги
def drawW():
    global animcount, car_score, lifes, speed
    if animcount + 1 >= 12:
        animcount = 0
    else:
        sc.blit(bg[animcount // 2], (0, 0))
        animcount += 1
    if lifes <= 0:
        sc.blit(bg[0], (0, 0))
    sc.blit(score, (0, 0))
    sc_text = f.render(f"Счёт: {car_score}", True, pygame.Color('black'))
    sc_text2 = f2.render(f"Жизней: {lifes}", True, pygame.Color('black'))
    sc_text3 = f3.render("GAME OVER", True, pygame.Color('red'))
    sc_text4 = f4.render("Нажмите r чтобы начать заново", True, pygame.Color('orange'))
    if lifes > 0:
        sc.blit(sc_text, (50, 100))
        sc.blit(sc_text2, (50, 140))
    cr.draw(sc)
    sc.blit(car_a, c_rect)
    if lifes <= 0:
        sc.blit(sc_text3, (50, 140))
        sc.blit(sc_text4, (290, 350))
        pygame.mixer.music.stop()
    if lifes <= 0:
        if keys[pygame.K_r]:
            car_score = 0
            lifes = 3
            sc.blit(sc_text, (30, 30))
            sc.blit(sc_text2, (30, 90))
            speed = 10
            pygame.mixer.music.play(-1)
    pygame.display.update()
    clock.tick(FPS)
    cr.update(H)


# Добавление машин
def create_car(group):
    indx = randint(0, len(cars_surf) - 1)
    x = randint(340, W - 340)
    speedx = randint(5, 10)

    return Spawn(x, speedx, cars_surf[indx], group)


car_score = 0
speed = 12


# Игра окончена
def game_over():
    global lifes, car_a, car_score, speed, f2
    for car in cr:
        if c_rect.collidepoint(car.rect.center):
            lifes -= 1
            car.kill()
            if lifes == 0:
                speed = 0


cr = pygame.sprite.Group()
create_car(cr)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
        elif event.type == pygame.USEREVENT:
            create_car(cr)
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        c_rect.x -= speed
        if c_rect.x < 215:
            c_rect.x = 215
    elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        c_rect.x += speed
        if c_rect.x > W - 474:
            c_rect.x = W - 474
    elif keys[pygame.K_UP] or keys[pygame.K_w]:
        c_rect.y -= speed
        if c_rect.y < 0:
            c_rect.y = 0
    elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
        c_rect.y += speed
        if c_rect.y > H + -250:
            c_rect.y = H + -250
    if keys[pygame.K_ESCAPE]:
        exit()
    drawW()
    game_over()
    if clock.tick(7000):
        car_score += randint(1, 5)
